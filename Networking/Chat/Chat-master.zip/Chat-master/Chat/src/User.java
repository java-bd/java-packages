import java.util.ArrayList;


public class User {
	public String name;
	public String password;
	public String[] anycast;
	public int region;
    public ArrayList<Integer> group = new ArrayList<Integer>();
	
}
