# simple_networking_java
A client that allows the user to enter a message and a server that continuously accepts socket connection, storing the received message and sending the pervious message back to the client.
