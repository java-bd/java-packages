import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class ClientGUI extends JFrame {
	private static final int PORT = 12345;
	
	private JTextArea _textArea;
	private JTextField _textField;
	private JLabel _textLabel;
	private ObjectOutputStream _outputStream;
	private ObjectInputStream _inputStream;

	public ClientGUI() {
		super("ClientGUI v2.12");
		setLayout(new BorderLayout());
		
		// _textArea
		_textArea = new JTextArea(4, 40);
		_textArea.setEditable(false);
		add(new JScrollPane(_textArea), BorderLayout.CENTER);
		
		// southPanel
		JPanel southPanel = new JPanel(new GridLayout(2,1));
		add(southPanel, BorderLayout.SOUTH);
		
		// _textLabel occupies the top part of southPanel
		_textLabel = new JLabel(" Enter a message: ");
		southPanel.add(_textLabel);
		
		// _textField occupies the bottom part of southPanel
		_textField = new JTextField(40);
		_textField.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ev) {
				sendMessage(_textField.getText());
				_textField.setText("");
				_textField.setEditable(false);
			}
		});
		southPanel.add(_textField);
	
		// more formatting
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		pack();
		setVisible(true);
		
		try {
			InetAddress address = InetAddress.getLocalHost();
			Socket socket = new Socket(address, PORT);
			
			_outputStream = new ObjectOutputStream(socket.getOutputStream());
			_outputStream.flush();
			
			_inputStream = new ObjectInputStream(socket.getInputStream());
			
			String msgFromServer = _inputStream.readUTF();
			_textArea.append(msgFromServer);
		
			_inputStream.close();
			_outputStream.close();
			socket.close();	
			
		} catch (IOException ex) {
			ex.printStackTrace();
		}		
	}
	
	private void sendMessage(String msgToServer) {
		if (_outputStream == null) {
			return;
		}

		try {
			_outputStream.writeUTF(msgToServer);
			_outputStream.flush();
		} catch (IOException ex) {
			System.err.println("Unable to send message" + ex);
		}
	}
	
	public static void main(String[] args) {
		new ClientGUI();
	}
}
